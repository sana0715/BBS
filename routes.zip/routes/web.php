<?php

use App\Http\Controllers\bbsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// laravelのトップページ
Route::get('/', function () {
    return view('welcome');
});


Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';

// ログイン
// Route::get('/login', [bbsController::class, 'login'])->name('login');

// 新規登録
Route::get('/signup', [bbsController::class, 'signup'])->name('signup');

// パスワード再設定
Route::get('/pass_reset', [bbsController::class, 'passReset'])->name('passReset');

// メイン(トップ)画面
Route::get('/main', [bbsController::class, 'main'])->name('main');

// フォローしてる人の投稿一覧
Route::get('/followposts', [bbsController::class, 'followposts'])->name('followposts');

// カテゴリー別投稿一覧
Route::get('/category_posts', [bbsController::class, 'categoryPosts'])->name('categoryPosts');

// カテゴリー別投稿詳細
Route::get('/catpost_detail', [bbsController::class, 'catpostDetail'])->name('catpostDetail');

// フォロー一覧
Route::get('/follow', [bbsController::class, 'follow'])->name('follow');

// 自分の投稿詳細
Route::get('/post_detail', [bbsController::class, 'postDetail'])->name('postDetail');

// 追加投稿
Route::get('/post', [bbsController::class, 'post'])->name('post');

// アカウント編集
Route::get('/user_edit', [bbsController::class, 'userEdit'])->name('userEdit');

// フォローしている人の投稿詳細
Route::get('/follow_postdetail', [bbsController::class, 'followPostdetail'])->name('followPostdetail');

// フォローしている人のメインページ
Route::get('/follow_main', [bbsController::class, 'followMain'])->name('followMain');

// 投稿編集
Route::get('/post_edit', [bbsController::class, 'postEdit'])->name('postEdit');

// 投稿削除
Route::get('/post_delete', [bbsController::class, 'postDelete'])->name('postDelete');

// いいね一覧
Route::get('/good', [bbsController::class, 'good'])->name('good');

// 投稿確認
Route::get('/post_confirm', [bbsController::class, 'postConfirm'])->name('postConfirm');

// アカウント編集確認
Route::get('/useredit_confirm', [bbsController::class, 'usereditConfirm'])->name('usereditConfirm');

// アカウント削除
Route::get('/user_delete', [bbsController::class, 'userDelete'])->name('userDelete');

// フォローしている人のフォロー一覧
Route::get('/follow_follow', [bbsController::class, 'followFollow'])->name('followFollow');

// 編集投稿確認
Route::get('/postedit_confirm', [bbsController::class, 'posteditConfirm'])->name('posteditConfirm');
